#include<iostream>
using namespace std;

int main()
{
	char m;

	cout << "Enter the character " << endl;
	cin >> m;

	cout << "ASCII value of the character " << m << " is : " << int(m) << endl;

	return 0;
}